# to generate raster plot
# Diana Hall
# 02-18-2016

library(meaRtools)

generate_raster_plot()









